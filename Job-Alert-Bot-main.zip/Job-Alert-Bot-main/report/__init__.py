# Report generation functionality
